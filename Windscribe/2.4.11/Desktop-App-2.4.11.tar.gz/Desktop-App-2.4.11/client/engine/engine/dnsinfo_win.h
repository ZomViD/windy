#ifndef DNSINFO_WIN_H
#define DNSINFO_WIN_H

class DnsInfo_win
{
public:
    static void outputDebugDnsInfo();
};

#endif // DNSINFO_WIN_H
