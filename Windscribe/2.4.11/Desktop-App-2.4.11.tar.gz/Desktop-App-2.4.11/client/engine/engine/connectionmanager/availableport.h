#ifndef AVAILABLEPORT_H
#define AVAILABLEPORT_H

class AvailablePort
{
public:
    static unsigned int getAvailablePort(unsigned int defaultPort);
};

#endif // AVAILABLEPORT_H
