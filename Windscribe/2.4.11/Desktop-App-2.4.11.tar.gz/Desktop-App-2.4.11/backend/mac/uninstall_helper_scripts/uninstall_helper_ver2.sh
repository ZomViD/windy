#! /bin/sh
launchctl unload /Library/LaunchDaemons/com.windscribe.helper.macos.plist
rm /Library/LaunchDaemons/com.windscribe.helper.macos.plist
rm /Library/PrivilegedHelperTools/com.windscribe.helper.macos