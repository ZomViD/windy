Scripts for uninstall Windscribe helpers from OS (run with sudo).

uninstallHelperVer1.sh -> uninstall helper for Windscribe 1.xx.
uninstallHelperVer2.sh -> uninstall helper for Windscribe 2.xx.