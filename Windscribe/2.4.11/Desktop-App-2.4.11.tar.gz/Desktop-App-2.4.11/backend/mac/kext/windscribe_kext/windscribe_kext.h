#ifndef WindscribeKext_h
#define WindscribeKext_h

#define BUNDLE_ID       "com.windscribe.kext"




#endif /* WindscribeKext_h */
