#ifndef IKEV2ROUTE_H
#define IKEV2ROUTE_H

class IKEv2Route
{
public:
    static bool addRouteForIKEv2();
};

#endif // IKEV2ROUTE_H
