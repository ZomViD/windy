#pragma once

// wrapper for API GetAdaptersAddresses and util functions
class AdaptersInfo
{
public:
	AdaptersInfo();

	bool isWindscribeAdapter(NET_IFINDEX index) const;
	bool getWindscribeIkev2AdapterInfo(NET_IFINDEX &outIfIndex, std::wstring &outIp);
	std::vector<NET_IFINDEX> getTAPAdapters();

private:
	std::unique_ptr< unsigned char[] > adapterInfoBuffer_;
    PIP_ADAPTER_ADDRESSES pAdapterInfo_ = NULL;

private:
    bool isWindscribeAdapter(PIP_ADAPTER_ADDRESSES ai) const;
};

