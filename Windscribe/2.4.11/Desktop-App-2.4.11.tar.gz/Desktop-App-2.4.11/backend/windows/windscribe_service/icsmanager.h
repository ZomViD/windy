#pragma once

class IcsManager
{
public:
	IcsManager();
	~IcsManager();

	bool isSupported();
};

