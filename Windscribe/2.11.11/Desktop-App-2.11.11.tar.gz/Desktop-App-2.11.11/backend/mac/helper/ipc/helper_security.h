#pragma once

#include <xpc/xpc.h>

namespace HelperSecurity {
    extern "C" bool isValidXpcConnection(xpc_object_t event);
}


