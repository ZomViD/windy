#pragma once

class IKEv2Route
{
public:
    static bool addRouteForIKEv2();
};
