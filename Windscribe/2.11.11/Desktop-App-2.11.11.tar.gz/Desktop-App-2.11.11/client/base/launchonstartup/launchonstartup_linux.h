#pragma once

class LaunchOnStartup_linux
{
public:
    static void setLaunchOnStartup(bool enable);
};
