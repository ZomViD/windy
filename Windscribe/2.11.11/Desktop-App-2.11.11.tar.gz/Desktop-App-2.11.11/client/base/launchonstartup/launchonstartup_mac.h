#pragma once

class LaunchOnStartup_mac
{
public:
    static bool isLaunchOnStartupEnabled();
    static void setLaunchOnStartup(bool enable);
};
